@extends('layouts.dashboard.master')
@section('content')
    <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
        <div class="flex-grow-1">
            <h4 class="fs-18 fw-semibold m-0">Categories</h4>
        </div>

        <div class="text-end">
            <ol class="breadcrumb m-0 py-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-primary">Dashboard</a></li>
                <li class="breadcrumb-item active">Categories</li>
            </ol>
        </div>
    </div>

    <a class="btn d-block btn-outline-primary mb-3" href="{{ route('categories.create') }}">Add Category</a>

    <div class="row row-sm">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive pt-3">
                        <table class="table datatable" id="datatable_1">
                            <thead>
                                <tr>
                                    <th class="wd-5p border-bottom-0">#</th>
                                    <th class="wd-15p border-bottom-0">Image</th>
                                    <th class="wd-40p border-bottom-0">Name</th>
                                    <th class="wd-15p border-bottom-0">Motorcycles</th>
                                    <th class="wd-25p border-bottom-0">Control</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($categories as $index => $category)
                                    <tr>
                                        <td>{{ ++$index }}</td>
                                        <td>
                                            @if ($category->image)
                                                <img src="{{ asset($category->image) }}" alt="{{ $category->name }}"
                                                    style="max-height: 50px; max-width: 100px; object-fit: contain;">
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td>{{ $category->name }}</td>
                                        <td>
                                            <span class="badge bg-secondary-subtle text-secondary">
                                                {{ $category->motorcycles_count }}
                                            </span>
                                        </td>
                                        <td class="text-start d-flex flex-nowrap">
                                            <a class="btn btn-sm bg-primary-subtle me-1"
                                                href="{{ route('categories.edit', $category->id) }}">
                                                <i class="mdi mdi-pencil fs-14"></i>
                                            </a>

                                            <button type="button" class="btn btn-sm bg-danger-subtle text-danger"
                                                data-bs-toggle="modal" data-bs-target="#deleteModal"
                                                data-route="{{ route('categories.destroy', $category->id) }}"
                                                data-name="{{ $category->name }}">
                                                <i class="mdi mdi-delete-outline fs-14"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Delete Confirmation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-0">
                            Are you sure you want to delete
                            <strong class="text-danger" id="form-name"></strong>?
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
                        <form id="deleteForm" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(document).ready(function() {
            $('#deleteModal').on('show.bs.modal', function(event) {
                let button = $(event.relatedTarget);
                $('#form-name').text(button.data('name'));
                $('#deleteForm').attr('action', button.data('route'));
            });
        });
    </script>
@endsection
